# Platform (AWS)

Same as a real org: **app Git** is this repo. **Cluster / ECR / RDS** are platform.

```text
infra/terraform/
  envs/dev
  envs/qa
  envs/production
```

Each env later owns: EKS, 11 ECR repos, one RDS, node IAM / IRSA.

This holiday you create those in **Console**. These folders are the org names so the layout matches work. Do not `terraform apply` until we write the modules together after the manual shop is up.
