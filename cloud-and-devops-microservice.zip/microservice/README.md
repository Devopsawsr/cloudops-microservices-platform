# Cloud and DevOps

Rechecked against a live org layout. Not one namespace. **Dev → QA → Production**, with CI, ConfigMaps, ServiceAccount, prod HPA/PDB, and Argo CD app-of-apps.

Read [docs/ORG-STRUCTURE.md](docs/ORG-STRUCTURE.md) — that is the picture you point to.

```text
services/                              product (own Dockerfile each)
packages/common/
.github/workflows/ci.yaml              CI
infra/terraform/envs/{dev,qa,production}
infra/k8s/base + overlays/dev|qa|production
infra/argocd/  project + root-app + apps/
```

## Zip

`~/Documents/Devops/MLOps/cloud-and-devops-microservice.zip`

## 3 days

**Fri — Dev, manual**

```bash
# set REPLACE_ECR in overlays/dev (and later qa/production)
kubectl apply -k infra/k8s/overlays/dev
kubectl -n cloudops-dev get svc gateway
```

**Sat** — RDS you create. Secret `cloudops-db` in `cloudops-dev`. Exam → certificate.

**Sun** — Argo CD: `project.yaml` + `root-app.yaml`. Dev/QA auto-sync. Production is **manual Sync**.
